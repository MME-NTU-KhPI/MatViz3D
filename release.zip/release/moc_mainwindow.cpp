/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QScreen>
#include <QtCharts/qlineseries.h>
#include <QtCharts/qabstractbarseries.h>
#include <QtCharts/qvbarmodelmapper.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCharts/qcandlestickseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qxyseries.h>
#include <QtCharts/qxyseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qxyseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[42];
    char stringdata0[11];
    char stringdata1[11];
    char stringdata2[1];
    char stringdata3[20];
    char stringdata4[8];
    char stringdata5[14];
    char stringdata6[12];
    char stringdata7[12];
    char stringdata8[16];
    char stringdata9[25];
    char stringdata10[6];
    char stringdata11[27];
    char stringdata12[22];
    char stringdata13[21];
    char stringdata14[17];
    char stringdata15[22];
    char stringdata16[34];
    char stringdata17[5];
    char stringdata18[23];
    char stringdata19[37];
    char stringdata20[6];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 10),  // "checkStart"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 19),  // "onLogMessageWritten"
        QT_MOC_LITERAL(43, 7),  // "message"
        QT_MOC_LITERAL(51, 13),  // "setupFileMenu"
        QT_MOC_LITERAL(65, 11),  // "saveAsImage"
        QT_MOC_LITERAL(77, 11),  // "exportToWRL"
        QT_MOC_LITERAL(89, 15),  // "setupWindowMenu"
        QT_MOC_LITERAL(105, 24),  // "onConsoleCheckBoxChanged"
        QT_MOC_LITERAL(130, 5),  // "state"
        QT_MOC_LITERAL(136, 26),  // "onAnimationCheckBoxChanged"
        QT_MOC_LITERAL(163, 21),  // "onDataCheckBoxChanged"
        QT_MOC_LITERAL(185, 20),  // "onAllCheckBoxChanged"
        QT_MOC_LITERAL(206, 16),  // "on_Start_clicked"
        QT_MOC_LITERAL(223, 21),  // "on_statistics_clicked"
        QT_MOC_LITERAL(245, 33),  // "on_checkBoxAnimation_stateCha..."
        QT_MOC_LITERAL(279, 4),  // "arg1"
        QT_MOC_LITERAL(284, 22),  // "on_AboutButton_clicked"
        QT_MOC_LITERAL(307, 36),  // "on_SliderAnimationSpeed_value..."
        QT_MOC_LITERAL(344, 5)   // "value"
    },
    "MainWindow",
    "checkStart",
    "",
    "onLogMessageWritten",
    "message",
    "setupFileMenu",
    "saveAsImage",
    "exportToWRL",
    "setupWindowMenu",
    "onConsoleCheckBoxChanged",
    "state",
    "onAnimationCheckBoxChanged",
    "onDataCheckBoxChanged",
    "onAllCheckBoxChanged",
    "on_Start_clicked",
    "on_statistics_clicked",
    "on_checkBoxAnimation_stateChanged",
    "arg1",
    "on_AboutButton_clicked",
    "on_SliderAnimationSpeed_valueChanged",
    "value"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x08,    1 /* Private */,
       3,    1,  105,    2, 0x08,    2 /* Private */,
       5,    0,  108,    2, 0x08,    4 /* Private */,
       6,    0,  109,    2, 0x08,    5 /* Private */,
       7,    0,  110,    2, 0x08,    6 /* Private */,
       8,    0,  111,    2, 0x08,    7 /* Private */,
       9,    1,  112,    2, 0x08,    8 /* Private */,
      11,    1,  115,    2, 0x08,   10 /* Private */,
      12,    1,  118,    2, 0x08,   12 /* Private */,
      13,    1,  121,    2, 0x08,   14 /* Private */,
      14,    0,  124,    2, 0x08,   16 /* Private */,
      15,    0,  125,    2, 0x08,   17 /* Private */,
      16,    1,  126,    2, 0x08,   18 /* Private */,
      18,    0,  129,    2, 0x08,   20 /* Private */,
      19,    1,  130,    2, 0x08,   21 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   20,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'checkStart'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onLogMessageWritten'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setupFileMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveAsImage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exportToWRL'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setupWindowMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onConsoleCheckBoxChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'onAnimationCheckBoxChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'onDataCheckBoxChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'onAllCheckBoxChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_Start_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_statistics_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_checkBoxAnimation_stateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_AboutButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_SliderAnimationSpeed_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->checkStart(); break;
        case 1: _t->onLogMessageWritten((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->setupFileMenu(); break;
        case 3: _t->saveAsImage(); break;
        case 4: _t->exportToWRL(); break;
        case 5: _t->setupWindowMenu(); break;
        case 6: _t->onConsoleCheckBoxChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->onAnimationCheckBoxChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->onDataCheckBoxChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 9: _t->onAllCheckBoxChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 10: _t->on_Start_clicked(); break;
        case 11: _t->on_statistics_clicked(); break;
        case 12: _t->on_checkBoxAnimation_stateChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 13: _t->on_AboutButton_clicked(); break;
        case 14: _t->on_SliderAnimationSpeed_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
